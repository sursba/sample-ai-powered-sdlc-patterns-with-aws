const { S3Client, PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');
const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime');

// Configuration - these will come from environment variables in Lambda
const BUCKET_NAME = process.env.BUCKET_NAME || 'domain-models';
const REGION = process.env.AWS_REGION || 'eu-north-1';
const BEDROCK_REGION = process.env.BEDROCK_REGION || 'eu-north-1';
const MODEL_ID = process.env.MODEL_ID || 'eu.anthropic.claude-3-7-sonnet-20250219-v1:0';

// Analysis types
const ANALYSIS_TYPES = {
  DOMAIN: 'domain',
  BUSINESS_CONTEXT: 'bounded',  // keeping 'bounded' for backward compatibility
  ASCII_DIAGRAM: 'ascii'
};

/**
 * Lambda handler function for domain model analysis
 * @param {Object} event - Lambda event object
 * @param {Object} context - Lambda context
 * @returns {Object} - Response object
 */
exports.handler = async (event, context) => {
  try {
    // Initialize clients first
    const s3Client = new S3Client({ region: REGION });
    const bedrockClient = new BedrockRuntimeClient({ region: BEDROCK_REGION });

    // Parse request body
    let body;
    if (event.body) {
      body = JSON.parse(event.body);
    } else {
      body = event;
    }

    // Extract image data and prompt
    let imageBase64 = body.imageBase64;
    const imageKey = body.imageKey;
    const prompt = body.prompt || '';
    const businessContext = body.businessContext || ''; // Added business context input
    const analysisType = body.analysisType || ANALYSIS_TYPES.DOMAIN; // 'domain', 'bounded', or 'ascii'

    // If imageKey is provided but no imageBase64, get the image from S3
    if (imageKey && !imageBase64) {
      try {
        const getObjectParams = {
          Bucket: BUCKET_NAME,
          Key: imageKey
        };

        const { Body } = await s3Client.send(new GetObjectCommand(getObjectParams));
        const chunks = [];

        for await (const chunk of Body) {
          chunks.push(chunk);
        }

        const imageBuffer = Buffer.concat(chunks);
        imageBase64 = imageBuffer.toString('base64');
      } catch (error) {
        throw error;
      }
    }

    if (!imageBase64 && !prompt && !businessContext) {
      return formatResponse(400, {
        success: false,
        error: 'Either image data, image key, prompt text, or business context is required'
      });
    }

    let result;
    let extractedText = '';
    let fileName = null;

    // If image is provided, extract text from it
    if (imageBase64) {
      // Convert base64 to buffer for S3 upload
      const imageBuffer = Buffer.from(imageBase64, 'base64');

      // Upload to S3
      fileName = `domain-model-${Date.now()}.jpg`;

      await s3Client.send(new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: fileName,
        Body: imageBuffer,
        ContentType: 'image/jpeg'
      }));

      // Extract text using Claude 3.7 vision
      extractedText = await extractTextFromImage(bedrockClient, imageBase64);
    }

    // Combine extracted text with any provided prompt
    const combinedInput = extractedText
      ? `${prompt}\n\nExtracted text from diagram:\n${extractedText}`
      : prompt;

    // Perform analysis based on type
    if (analysisType === ANALYSIS_TYPES.BUSINESS_CONTEXT) {
      result = await generateBusinessContexts(bedrockClient, s3Client, combinedInput);
    } else if (analysisType === ANALYSIS_TYPES.ASCII_DIAGRAM) {
      // For ASCII diagram, use both the combined input and business context if available
      const diagramInput = businessContext
        ? `${combinedInput}\n\nBusiness Context Analysis:\n${businessContext}`
        : combinedInput;
      result = await generateAsciiDiagram(bedrockClient, s3Client, diagramInput);
    } else {
      result = await analyzeDomainModel(bedrockClient, s3Client, combinedInput);
    }

    return formatResponse(200, {
      success: true,
      imageS3Key: fileName,
      ...result
    });

  } catch (error) {
    return formatResponse(500, {
      success: false,
      error: error.message
    });
  }
};

/**
 * Format Lambda response with proper headers
 * @param {number} statusCode - HTTP status code
 * @param {Object} body - Response body
 * @returns {Object} - Formatted response
 */
function formatResponse(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
    },
    body: JSON.stringify(body)
  };
}

/**
 * Extract text from an image using Claude 3.7 vision
 * @param {BedrockRuntimeClient} bedrockClient - Bedrock client
 * @param {string} imageBase64 - Base64 encoded image
 * @returns {string} - Extracted text
 */
async function extractTextFromImage(bedrockClient, imageBase64) {
  const extractTextPrompt = {
    role: 'user',
    content: [
      {
        type: 'text',
        text: 'Extract all text content from this domain model image. Return only the text you can read from the image, including entity names, attributes, relationships, and any labels or annotations.'
      },
      {
        type: 'image',
        source: {
          type: 'base64',
          media_type: 'image/jpeg',
          data: imageBase64
        }
      }
    ]
  };

  const extractCommand = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      max_tokens: 1500,
      messages: [extractTextPrompt]
    })
  });

  const extractResponse = await bedrockClient.send(extractCommand);
  const extractBody = JSON.parse(new TextDecoder().decode(extractResponse.body));
  return extractBody.content[0].text;
}

/**
 * Analyze domain model
 * @param {BedrockRuntimeClient} bedrockClient - Bedrock client
 * @param {S3Client} s3Client - S3 client
 * @param {string} inputText - Text to analyze
 * @returns {Object} - Analysis result
 */
async function analyzeDomainModel(bedrockClient, s3Client, inputText) {
  if (!inputText) {
    throw new Error('No input text provided for analysis');
  }

  const analyzePrompt = {
    role: 'user',
    content: [
      {
        type: 'text',
        text: `Analyze this domain model text and identify key entities, attributes, and relationships:

${inputText}

Provide analysis in this format:
ENTITIES: List all entities
ATTRIBUTES: Key attributes for each entity
RELATIONSHIPS: How entities connect
DOMAIN INSIGHTS: Business rules and patterns`
      }
    ]
  };

  const analyzeCommand = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      max_tokens: 2000,
      messages: [analyzePrompt]
    })
  });

  const analyzeResponse = await bedrockClient.send(analyzeCommand);
  const analyzeBody = JSON.parse(new TextDecoder().decode(analyzeResponse.body));
  const domainAnalysis = analyzeBody.content[0].text;

  // Save domain analysis to S3
  const analysisFileName = `domain-analysis-${Date.now()}.txt`;
  await s3Client.send(new PutObjectCommand({
    Bucket: BUCKET_NAME,
    Key: analysisFileName,
    Body: domainAnalysis,
    ContentType: 'text/plain'
  }));

  return {
    analysisS3Key: analysisFileName,
    domainAnalysis
  };
}

/**
 * Generate business contexts
 * @param {BedrockRuntimeClient} bedrockClient - Bedrock client
 * @param {S3Client} s3Client - S3 client
 * @param {string} domainAnalysisText - Domain analysis text
 * @returns {Object} - Business contexts result
 */
async function generateBusinessContexts(bedrockClient, s3Client, domainAnalysisText) {
  if (!domainAnalysisText) {
    throw new Error('No domain analysis text provided');
  }

  const contextPrompt = {
    role: 'user',
    content: [{
      type: 'text',
      text: `Based on this domain analysis, identify business contexts and their communications:

${domainAnalysisText}

Generate:
1. BUSINESS CONTEXTS: Distinct business domains
2. CONTEXT BOUNDARIES: What belongs in each context
3. INTEGRATION PATTERNS: How contexts communicate
4. DOMAIN EVENTS: Events crossing boundaries
5. API CONTRACTS: Interfaces between contexts

Format as structured analysis.`
    }]
  };

  const command = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      max_tokens: 3000,
      messages: [contextPrompt]
    })
  });

  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  const businessContextAnalysis = responseBody.content[0].text;

  // Save to S3
  const contextFileName = `business-contexts-${Date.now()}.txt`;

  await s3Client.send(new PutObjectCommand({
    Bucket: BUCKET_NAME,
    Key: contextFileName,
    Body: businessContextAnalysis,
    ContentType: 'text/plain'
  }));

  return {
    businessContextS3Key: contextFileName,
    businessContextAnalysis
  };
}

/**
 * Generate ASCII diagram of business contexts and their interactions
 * @param {BedrockRuntimeClient} bedrockClient - Bedrock client
 * @param {S3Client} s3Client - S3 client
 * @param {string} inputText - Text to analyze (can include both domain model and business context)
 * @returns {Object} - ASCII diagram result
 */
async function generateAsciiDiagram(bedrockClient, s3Client, inputText) {
  if (!inputText) {
    throw new Error('No input text provided for ASCII diagram generation');
  }

  const diagramPrompt = {
    role: 'user',
    content: [{
      type: 'text',
      text: `Based on this domain description and business context analysis, create an ASCII diagram showing business contexts and their interactions:

${inputText}

First, identify the key business contexts and how they interact with each other.
Then create an ASCII diagram that shows:
1. Each business context as a box with its name
2. Arrows between contexts showing their interactions
3. Brief labels on the arrows describing the type of interaction

Use ASCII characters to create a clear, readable diagram.
Make sure the diagram fits well in a fixed-width terminal or text editor.
Include a legend explaining any symbols used.

Create the most informative and clear ASCII diagram possible based on the domain description.`
    }]
  };

  const command = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      max_tokens: 4000,
      messages: [diagramPrompt]
    })
  });

  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  const asciiDiagram = responseBody.content[0].text;

  // Save to S3
  const diagramFileName = `business-context-diagram-${Date.now()}.txt`;

  await s3Client.send(new PutObjectCommand({
    Bucket: BUCKET_NAME,
    Key: diagramFileName,
    Body: asciiDiagram,
    ContentType: 'text/plain'
  }));

  return {
    asciiDiagramS3Key: diagramFileName,
    asciiDiagram
  };
}