const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime');

// Configuration
const BEDROCK_REGION = process.env.BEDROCK_REGION || 'eu-west-1';
const MODEL_ID = process.env.MODEL_ID || 'eu.anthropic.claude-3-7-sonnet-20250219-v1:0';

/**
 * Clean and parse JSON response from Claude
 * @param {string} text - Raw text response
 * @returns {Object} - Parsed JSON object
 */
function cleanAndParseJson(text) {
  try {
    // Remove any text before the first { and after the last }
    const startIdx = text.indexOf('{');
    const endIdx = text.lastIndexOf('}');
    
    if (startIdx === -1 || endIdx === -1 || endIdx <= startIdx) {
      throw new Error("Could not find valid JSON object in the text");
    }
    
    let jsonText = text.substring(startIdx, endIdx + 1);
    
    // Try to parse as is first
    try {
      return JSON.parse(jsonText);
    } catch (parseError) {
      console.log(`Initial JSON parsing error: ${parseError.message}`);
      
      // Try to fix common JSON issues
      if (parseError.message.includes("Unterminated string")) {
        // Replace newlines inside strings with \n
        jsonText = jsonText.replace(/"([^"]*)\n/g, '"$1\\n');
        
        try {
          return JSON.parse(jsonText);
        } catch (fixError) {
          console.log(`Fixed JSON parsing failed: ${fixError.message}`);
        }
      }
      
      // If all fixes fail, return fallback response
      console.log(`All JSON parsing attempts failed. Raw text: ${text}`);
      return {
        error: `Failed to parse JSON: ${parseError.message}`,
        fallback: true,
        message: "Using fallback response due to parsing error"
      };
    }
  } catch (error) {
    console.log(`Error in cleanAndParseJson: ${error.message}`);
    console.log(`Raw text: ${text}`);
    
    return {
      error: `Failed to parse JSON: ${error.message}`,
      fallback: true,
      message: "Using fallback response due to parsing error"
    };
  }
}

/**
 * Generate security definitions based on domain access patterns
 * @param {Object} openApiSpec - OpenAPI specification
 * @returns {Object} - Security definitions
 */
async function generateSecurityDefinitions(openApiSpec) {
  const bedrockClient = new BedrockRuntimeClient({ region: BEDROCK_REGION });
  
  // Extract only the security-related parts of the spec
  const securitySpec = {
    info: openApiSpec.info || {},
    components: {
      securitySchemes: openApiSpec.components?.securitySchemes || {}
    },
    security: openApiSpec.security || []
  };
  
  // Add a sample of paths to provide context
  securitySpec.paths = {};
  const paths = openApiSpec.paths || {};
  const pathKeys = Object.keys(paths).slice(0, 5); // Take up to 5 paths
  pathKeys.forEach(key => {
    securitySpec.paths[key] = paths[key];
  });
  
  const prompt = `Generate security definitions based on domain access patterns for this API.
Return a JSON object with the key "securityDefinitions" containing:
1. Recommended security schemes (OAuth2, JWT, API Key, etc.)
2. Access control patterns based on domain roles
3. Security recommendations specific to this API's domain

Return ONLY the JSON object. No explanations.

API Specification:
${JSON.stringify(securitySpec, null, 2)}`;

  const command = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.1,
      max_tokens: 3000
    })
  });

  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  const rawCompletion = responseBody.content[0].text;
  
  return cleanAndParseJson(rawCompletion);
}

/**
 * Create API governance policies aligned with domain rules
 * @param {Object} openApiSpec - OpenAPI specification
 * @returns {Object} - Governance policies
 */
async function generateApiGovernance(openApiSpec) {
  const bedrockClient = new BedrockRuntimeClient({ region: BEDROCK_REGION });
  
  // Extract only the parts needed for governance policies
  const governanceSpec = {
    info: openApiSpec.info || {},
    paths: {}
  };
  
  // Add a sample of paths
  const paths = openApiSpec.paths || {};
  const pathKeys = Object.keys(paths).slice(0, 10); // Take up to 10 paths
  pathKeys.forEach(key => {
    governanceSpec.paths[key] = paths[key];
  });
  
  const prompt = `Create API governance policies aligned with domain rules for this API.
Return a JSON object with the key "policies" containing these sub-objects:
1. "rateLimiting": Rate limits for each endpoint type
2. "caching": Caching strategies for different resources
3. "validation": Input validation rules based on domain constraints

Return ONLY the JSON object. No explanations.

API Specification:
${JSON.stringify(governanceSpec, null, 2)}`;

  const command = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.1,
      max_tokens: 3000
    })
  });

  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  const rawCompletion = responseBody.content[0].text;
  
  return cleanAndParseJson(rawCompletion);
}

/**
 * Add API documentation with domain-specific examples and descriptions
 * @param {Object} openApiSpec - OpenAPI specification
 * @returns {Object} - API documentation
 */
function generateApiDocumentation(openApiSpec) {
  // Extract the paths from the OpenAPI spec
  const paths = openApiSpec.paths || {};
  
  // If there are no paths, return a simple message
  if (Object.keys(paths).length === 0) {
    return {
      documentation: {
        message: "No paths found in the OpenAPI specification.",
        recommendation: "Add paths to your OpenAPI specification to generate documentation."
      }
    };
  }
  
  // Create a simplified documentation structure directly from the OpenAPI spec
  const documentation = {};
  
  Object.entries(paths).forEach(([path, pathItem]) => {
    documentation[path] = {};
    
    // Process each HTTP method (get, post, put, etc.)
    Object.entries(pathItem).forEach(([method, operation]) => {
      if (['get', 'post', 'put', 'delete', 'patch', 'options', 'head'].includes(method)) {
        // Extract basic information from the operation
        const docEntry = {
          summary: operation.summary || "No summary provided",
          description: operation.description || "No description provided",
          operationId: operation.operationId || `${method}_${path.replace(/\//g, '_')}`
        };
        
        // Extract parameters
        if (operation.parameters) {
          docEntry.parameters = operation.parameters.map(param => ({
            name: param.name || "unnamed",
            in: param.in || "query",
            description: param.description || "No description",
            required: param.required || false
          }));
        }
        
        // Extract responses
        if (operation.responses) {
          docEntry.responses = {};
          Object.entries(operation.responses).forEach(([statusCode, response]) => {
            docEntry.responses[statusCode] = {
              description: response.description || "No description"
            };
          });
        }
        
        // Add to documentation
        documentation[path][method] = docEntry;
      }
    });
  });
  
  return { documentation };
}

/**
 * Generate API versioning strategy based on domain evolution patterns
 * @param {Object} openApiSpec - OpenAPI specification
 * @returns {Object} - Versioning strategy
 */
async function generateVersioningStrategy(openApiSpec) {
  const bedrockClient = new BedrockRuntimeClient({ region: BEDROCK_REGION });
  
  // Extract only the parts needed for versioning strategy
  const versionSpec = {
    info: openApiSpec.info || {},
    tags: openApiSpec.tags || []
  };
  
  const prompt = `Generate an API versioning strategy based on domain evolution patterns.
Return a JSON object with the key "versioning" containing:
1. Recommended versioning approach (URI, header, query parameter)
2. Version lifecycle management strategy
3. Backward compatibility guidelines
4. Domain-specific evolution considerations

Return ONLY the JSON object. No explanations.

API Specification:
${JSON.stringify(versionSpec, null, 2)}`;

  const command = new InvokeModelCommand({
    modelId: MODEL_ID,
    contentType: 'application/json',
    accept: 'application/json',
    body: JSON.stringify({
      anthropic_version: 'bedrock-2023-05-31',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.1,
      max_tokens: 3000
    })
  });

  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  const rawCompletion = responseBody.content[0].text;
  
  return cleanAndParseJson(rawCompletion);
}

/**
 * Lambda handler function
 * @param {Object} event - Lambda event object
 * @param {Object} context - Lambda context
 * @returns {Object} - Response object
 */
exports.handler = async (event, context) => {
  try {
    console.log("Lambda handler received event:", JSON.stringify(event).substring(0, 200) + "...");
    
    // The event is the OpenAPI spec directly
    const openApiSpec = event;
    
    // Check if a specific task is requested
    const task = (typeof event === 'object' && event.task) ? event.task : null;
    
    try {
      if (task === "security") {
        // Generate only security definitions
        const result = await generateSecurityDefinitions(openApiSpec);
        
        // Check if we got a fallback response due to parsing error
        if (result.fallback) {
          return {
            statusCode: 200,
            body: JSON.stringify({
              message: "Security definitions generated with fallback",
              result: {
                securityDefinitions: {
                  schemes: [
                    {
                      type: "oauth2",
                      name: "OAuth2",
                      description: "OAuth2 authentication with authorization code flow"
                    },
                    {
                      type: "http",
                      scheme: "bearer",
                      bearerFormat: "JWT",
                      name: "JWT",
                      description: "JWT token-based authentication"
                    },
                    {
                      type: "apiKey",
                      name: "API Key",
                      in: "header",
                      description: "API key for service-to-service authentication"
                    }
                  ],
                  recommendations: [
                    "Implement token-based authentication with short-lived JWTs",
                    "Use HTTPS for all API endpoints",
                    "Implement rate limiting per user and IP address",
                    "Apply strict CORS policies for browser-based clients",
                    "Implement input validation for all endpoints"
                  ],
                  error: result.error || "Unknown parsing error"
                }
              }
            }, null, 2)
          };
        }
        
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: "Security definitions generated successfully",
            result
          }, null, 2)
        };
      } else if (task === "governance") {
        // Generate only governance policies
        const result = await generateApiGovernance(openApiSpec);
        
        // Check if we got a fallback response due to parsing error
        if (result.fallback) {
          return {
            statusCode: 200,
            body: JSON.stringify({
              message: "API governance policies generated with fallback",
              result: {
                policies: {
                  rateLimiting: {
                    default: "100 requests per minute",
                    authenticated: "300 requests per minute",
                    premium: "1000 requests per minute"
                  },
                  caching: {
                    GET: "Cache for 5 minutes",
                    POST: "No caching",
                    PUT: "No caching",
                    DELETE: "No caching"
                  },
                  validation: "Apply schema validation to all requests",
                  error: result.error || "Unknown parsing error"
                }
              }
            }, null, 2)
          };
        }
        
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: "API governance policies generated successfully",
            result
          }, null, 2)
        };
      } else if (task === "documentation") {
        // Generate only API documentation
        const result = generateApiDocumentation(openApiSpec);
        
        // Check if we got a fallback response due to parsing error
        if (result.fallback) {
          return {
            statusCode: 200,
            body: JSON.stringify({
              message: "API documentation generated with fallback",
              result: {
                documentation: {
                  endpoints: "Documentation could not be generated due to parsing error",
                  error: result.error || "Unknown parsing error"
                }
              }
            }, null, 2)
          };
        }
        
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: "API documentation generated successfully",
            result
          }, null, 2)
        };
      } else if (task === "versioning") {
        // Generate only versioning strategy
        const result = await generateVersioningStrategy(openApiSpec);
        
        // Check if we got a fallback response due to parsing error
        if (result.fallback) {
          return {
            statusCode: 200,
            body: JSON.stringify({
              message: "API versioning strategy generated with fallback",
              result: {
                versioning: {
                  recommendedApproach: "header",
                  approach: {
                    name: "Accept-Version header",
                    format: "Accept-Version: v{major}"
                  },
                  error: result.error || "Unknown parsing error"
                }
              }
            }, null, 2)
          };
        }
        
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: "API versioning strategy generated successfully",
            result
          }, null, 2)
        };
      } else {
        // Generate all components sequentially
        let securityResult, governanceResult, documentationResult, versioningResult;
        
        try {
          securityResult = await generateSecurityDefinitions(openApiSpec);
        } catch (secError) {
          console.log(`Error generating security definitions: ${secError.message}`);
          securityResult = { fallback: true, error: secError.message };
        }
        
        try {
          governanceResult = await generateApiGovernance(openApiSpec);
        } catch (govError) {
          console.log(`Error generating governance policies: ${govError.message}`);
          governanceResult = { fallback: true, error: govError.message };
        }
        
        try {
          documentationResult = generateApiDocumentation(openApiSpec);
        } catch (docError) {
          console.log(`Error generating API documentation: ${docError.message}`);
          documentationResult = { fallback: true, error: docError.message };
        }
        
        try {
          versioningResult = await generateVersioningStrategy(openApiSpec);
        } catch (verError) {
          console.log(`Error generating versioning strategy: ${verError.message}`);
          versioningResult = { fallback: true, error: verError.message };
        }
        
        // Combine all results
        const combinedResult = {
          securityDefinitions: securityResult.securityDefinitions || {},
          policies: governanceResult.policies || {},
          documentation: documentationResult.documentation || {},
          versioning: versioningResult.versioning || {}
        };
        
        // Add error information if any component failed
        const hasErrors = [securityResult, governanceResult, documentationResult, versioningResult]
          .some(result => result.fallback);
        
        if (hasErrors) {
          combinedResult.errors = {
            security: securityResult.fallback ? securityResult.error : null,
            governance: governanceResult.fallback ? governanceResult.error : null,
            documentation: documentationResult.fallback ? documentationResult.error : null,
            versioning: versioningResult.fallback ? versioningResult.error : null
          };
        }
        
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: `Comprehensive API documentation generated${hasErrors ? ' with some fallbacks' : ' successfully'}`,
            parsed_json: combinedResult,
            has_errors: hasErrors
          }, null, 2)
        };
      }
    } catch (taskError) {
      console.log(`Error processing task ${task}: ${taskError.message}`);
      
      // Return a more helpful error with fallback data
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: `Error processing ${task || 'documentation'} task`,
          error: taskError.message,
          type: taskError.constructor.name,
          fallback: true,
          parsed_json: {
            securityDefinitions: {
              schemes: [
                { type: "oauth2", name: "OAuth2", description: "OAuth2 authentication" },
                { type: "http", scheme: "bearer", name: "JWT", description: "JWT authentication" }
              ],
              recommendations: ["Use HTTPS", "Implement rate limiting"]
            },
            policies: {},
            documentation: {},
            versioning: { recommendedApproach: "header" }
          }
        }, null, 2)
      };
    }
  } catch (error) {
    console.log(`Lambda handler error: ${error.message}`);
    
    // Return a 200 with error information to avoid breaking the client
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: false,
        error: error.message,
        type: error.constructor.name,
        fallback: true,
        parsed_json: {
          securityDefinitions: {
            schemes: [
              { type: "oauth2", name: "OAuth2", description: "OAuth2 authentication" },
              { type: "http", scheme: "bearer", name: "JWT", description: "JWT authentication" }
            ]
          },
          policies: {},
          documentation: {},
          versioning: { recommendedApproach: "header" }
        }
      }, null, 2)
    };
  }
};